package co.edu.udea.CasoPracticoMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasoPracticoMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasoPracticoMsApplication.class, args);
	}

}
