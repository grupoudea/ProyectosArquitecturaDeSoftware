package co.edu.udea.CasoPracticoMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasoPracticoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
